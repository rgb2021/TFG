#ifndef _TIMER_PWM_H_
#define _TIMER_PWM_H_
#include "sys.h"

void TIM3_PWM_Init(u16 arr,u16 psc);


#endif
