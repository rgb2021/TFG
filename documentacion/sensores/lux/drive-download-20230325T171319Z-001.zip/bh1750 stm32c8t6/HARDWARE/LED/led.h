#ifndef __LED_H
#define __LED_H	 
#include "sys.h"

#define SYS_LED PCout(13)// PC13

void LED_Init(void);//��ʼ��
void LED1_Init(void);
		 				    
#endif
