import json
import boto3
import time
from datetime import datetime

def encolarMensaje (mensaje) :
   now = datetime.now()
   current_time = now.strftime("%H:%M:%S %p")
   
   sqs = boto3.client('sqs')  #client is required to interact with 
   sqs.send_message(
       QueueUrl="https://sqs.eu-central-1.amazonaws.com/329640145453/ColaMensajesBotTelegram.fifo",
       MessageBody=json.dumps(mensaje),
       MessageGroupId='TelegramBot',
       MessageDeduplicationId= str(time.time())
   )
   

def lambda_handler(event, context):  #required
   
   encolarMensaje(event)
   print('encolado mensaje:')
   print(event)
   
   return {
        'statusCode': 200,
        'body': 'encolado'
    }