import boto3

# Crear cliente de DynamoDB
dynamodb = boto3.client('dynamodb')

def lambda_handler(event, context):
    # Obtener el estado de 'estado' y 'variable' desde el evento de Lambda
    estado = event['estado']
    variable = event['variable']

    # Definir clave principal del elemento a actualizar
    key = {
        'id': {'S': 'valoresActuales'}
    }

    # Definir expresión de actualización
    update_expression = 'SET #variable.estado = :estado'

    # Definir los nombres de atributos que podrían ser palabras reservadas
    attribute_names = {
        "#variable": variable
    }

    # Definir valores para los parámetros de la expresión de actualización
    expression_attribute_values = {
        ':estado': {'S': str(estado)}
    }

    # Ejecutar la operación UpdateItem para actualizar el elemento
    response = dynamodb.update_item(
        TableName='estados',
        Key=key,
        UpdateExpression=update_expression,
        ExpressionAttributeNames=attribute_names,
        ExpressionAttributeValues=expression_attribute_values
    )

    print(response)