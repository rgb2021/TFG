import json
import boto3
import datetime
import dateutil.tz

# Crear cliente de DynamoDB
dynamodb = boto3.client('dynamodb')

def actualizarVariables (maximo,minimo) :
    events_client = boto3.client('iotevents-data')

    # Actualiza las variables en AWS IoT Events
    response = events_client.batch_update_detector(
        detectors=[
            {
                'messageId': 'updatedetectorLux',
                'detectorModelName': 'detectorLux',
                'state': {
                    'stateName': 'Inicializar',
                    'variables': [
                        {
                            'name': 'valorMaximo',
                            'value': str(maximo)
                        },
                        {
                            'name': 'valorMinimo',
                            'value': str(minimo)
                        },
                    ],
                    'timers': []
                }
            },
        ]
    )
    
    # Actualiza las variables en AWS IoT Events
    response = events_client.batch_update_detector(
        detectors=[
            {
                'messageId': 'updatedetectorLux',
                'detectorModelName': 'detectorLux',
                'state': {
                    'stateName': 'valorPorEncima',
                    'variables': [
                        {
                            'name': 'valorMaximo',
                            'value': str(maximo)
                        },
                        {
                            'name': 'valorMinimo',
                            'value': str(minimo)
                        },
                    ],
                    'timers': []
                }
            },
        ]
    )
    
     # Actualiza las variables en AWS IoT Events
    response = events_client.batch_update_detector(
        detectors=[
            {
                'messageId': 'updatedetectorLux',
                'detectorModelName': 'detectorLux',
                'state': {
                    'stateName': 'valorOK',
                    'variables': [
                        {
                            'name': 'valorMaximo',
                            'value': str(maximo)
                        },
                        {
                            'name': 'valorMinimo',
                            'value': str(minimo)
                        },
                    ],
                    'timers': []
                }
            },
        ]
    )
    
     # Actualiza las variables en AWS IoT Events
    response = events_client.batch_update_detector(
        detectors=[
            {
                'messageId': 'updatedetectorLux',
                'detectorModelName': 'detectorLux',
                'state': {
                    'stateName': 'valorPorDebajo',
                    'variables': [
                        {
                            'name': 'valorMaximo',
                            'value': str(maximo)
                        },
                        {
                            'name': 'valorMinimo',
                            'value': str(minimo)
                        },
                    ],
                    'timers': []
                }
            },
        ]
    )
    

def lambda_handler(event, context):

    # Crear una instancia del cliente DynamoDB
    dynamodb = boto3.client('dynamodb')

    # Consultar la tabla DynamoDB
    response = dynamodb.get_item(
        TableName='estados',
        Key={
            'id': {'S': 'valoresActuales'}
        }
    )

    # Obtener el valor correspondiente a la hora solicitada
    minimo = response['Item']['lux']['M']['minimo']['N']
    maximo = response['Item']['lux']['M']['maximo']['N']
    #maximo = horario['M']['hora{}'.format(hora)]
    
    #maximo = int(valor['N']) + margen
    #minimo = int(valor['N']) - margen
    
    actualizarVariables(maximo,minimo)

    # Devolver el valor encontrado
    return {
        
        'maximo': minimo,
        'minimo': maximo,
        
    }