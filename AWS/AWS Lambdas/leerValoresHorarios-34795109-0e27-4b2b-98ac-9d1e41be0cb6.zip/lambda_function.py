import json
import boto3
import datetime
import dateutil.tz

# Crear cliente de DynamoDB
dynamodb = boto3.client('dynamodb')

def actualizarLimites (variable,maximo,minimo) :
    # Crear una instancia del cliente Lambda
    lambda_client = boto3.client('lambda')

    # Parámetros para la invocación de la función Lambda objetivo
    function_name = 'actualizarLimites'
    payload = {
        'minimo': minimo,
        'maximo': maximo,
        'variable': variable
    }

    # Invocar a la función Lambda objetivo
    response = lambda_client.invoke(
        FunctionName=function_name,
        InvocationType='RequestResponse',  # Puedes cambiar el tipo de invocación según tus necesidades
        Payload=json.dumps(payload)
    )

    # Obtener el resultado de la función Lambda objetivo
    result = json.loads(response['Payload'].read())

    print(result)
    
def actualizarVariables (maximo,minimo) :

    # Configurar el cliente de AWS IoT Events
    iot_events_client = boto3.client('iotevents-data')
    
    # Nombre del detector de eventos
    detector_name = 'detectorLux'
    
     # Definir los datos a enviar al detector de eventos
    data = {
        "lux": {
            "maximo": maximo,
            "minimo": minimo
        }
    }

    # Convertir los datos a formato JSON
    payload = json.dumps(data)
    
     # Enviar los datos al detector de eventos
    iot_events_client.batch_put_message(
        messages=[
            {
                'inputName': 'actualizacionLimites',  # Nombre del input en el detector de eventos
                'messageId': '1',  # ID único del mensaje
                'payload': payload
            }
        ]
    )
    
    print(payload)
    # Imprimir mensaje de éxito
    print("Datos enviados al detector de eventos")

def lambda_handler(event, context):
    # Obtener el valor de hora pasado por parámetro y el id de la propiedad
    
    zona_horaria_esp = dateutil.tz.gettz('Europe/Madrid');
    fecha_actual = datetime.datetime.now(zona_horaria_esp).time()
    hora = fecha_actual.hour
    margen = event['margen']
    idPropiedad = event['id']

    # Crear una instancia del cliente DynamoDB
    dynamodb = boto3.client('dynamodb')

    # Consultar la tabla DynamoDB
    response = dynamodb.get_item(
        TableName='horario',
        Key={
            'id': {'S': idPropiedad}
        }
    )

    # Obtener el valor correspondiente a la hora solicitada
    horario = response['Item']['horario']
    valor = horario['M']['hora{}'.format(hora)]
    
    maximo = int(valor['N']) + margen
    minimo = int(valor['N']) - margen
    
    actualizarLimites(idPropiedad,maximo,minimo)
    actualizarVariables(maximo,minimo)
    
    # Devolver el valor encontrado
    return {
        'hora': hora,
        'valor': valor['N'],
        'maximo': maximo,
        'minimo': minimo,
        'propiedad': idPropiedad
    }