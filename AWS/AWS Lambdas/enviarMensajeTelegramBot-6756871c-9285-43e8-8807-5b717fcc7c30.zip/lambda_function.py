import boto3
import json
import os
import requests


def lambda_handler(event, context):

    print(json.dumps(event))
    chat_id = os.environ['CHATID']
    telegram_token = os.environ['TOKEN']
    api_url = f"https://api.telegram.org/bot{telegram_token}/"

    records = event['Records']
    for record in records:
        content = record['body']
        print(content)
    
        params = {'chat_id': chat_id, 'text': json.loads(content)['mensaje']}
        res = requests.post(f"{api_url}sendMessage", data=params).json()    
        
    return     {
        'statusCode': 200,
        'body': 'mensajeEnviado'
    }
