import boto3
import json
import os
import requests


def saludo():
    return "que pasa cabesa"
    
def dameCadenaPropiedad (titulo,estado,maximo,minimo,valor):
    res=titulo
    if (estado=='ok'):
        res += ('\n        👍️ Estado: ')
        res += (estado)
    else:
        res += ('\n        👎 Estado: ')
        res += (estado)
    res += ('\n        🔼️ Máximo: ')
    res += (maximo)
    res += ('\n        🔽️ Mínimo: ')
    res += (minimo)
    if (estado=='ok'):
        res += ('\n        ✅ Valor actual: ')
        res += (valor)
    
    else:
        res += ('\n        ❌Valor actual: ')
        res += (valor)    
    
    res += ('\n')
    
    return res

    
def dameDatosEstados():
    # Nombre de la tabla DynamoDB
    tabla = 'estados'

    # Crear una instancia del cliente de DynamoDB
    dynamodb = boto3.client('dynamodb')

    try:
        # Obtener el item de la tabla DynamoDB
        response = dynamodb.get_item(
            TableName=tabla,
            Key={
                'id': {'S': 'valoresActuales'}
            }
        )

        # Leer los valores de cada atributo
        item = response['Item']
        humedad = item.get('humedad', {}).get('M', {})
        humedad_suelo = item.get('humedadSuelo', {}).get('M', {})
        lux = item.get('lux', {}).get('M', {})
        temperatura = item.get('temperatura', {}).get('M', {})

        # Leer los valores específicos de cada atributo
        estado_humedad = humedad.get('estado', {}).get('S', '')
        maximo_humedad = humedad.get('maximo', {}).get('N', '')
        minimo_humedad = humedad.get('minimo', {}).get('N', '')
        valor_actual_humedad = humedad.get('valorActual', {}).get('N', '')

        estado_humedad_suelo = humedad_suelo.get('estado', {}).get('S', '')
        maximo_humedad_suelo = humedad_suelo.get('maximo', {}).get('N', '')
        minimo_humedad_suelo = humedad_suelo.get('minimo', {}).get('N', '')
        valor_actual_humedad_suelo = humedad_suelo.get('valorActual', {}).get('N', '')

        estado_lux = lux.get('estado', {}).get('S', '')
        maximo_lux = lux.get('maximo', {}).get('N', '')
        minimo_lux = lux.get('minimo', {}).get('N', '')
        valor_actual_lux = lux.get('valorActual', {}).get('N', '')

        estado_temperatura = temperatura.get('estado', {}).get('S', '')
        maximo_temperatura = temperatura.get('maximo', {}).get('N', '')
        minimo_temperatura = temperatura.get('minimo', {}).get('N', '')
        valor_actual_temperatura = temperatura.get('valorActual', {}).get('N', '')

        res =  dameCadenaPropiedad('💧 Humedad ',estado_humedad,maximo_humedad,minimo_humedad,valor_actual_humedad)
        res += dameCadenaPropiedad('🪴 Humedad del suelo ',estado_humedad_suelo,maximo_humedad_suelo,minimo_humedad_suelo,valor_actual_humedad_suelo)
        res += dameCadenaPropiedad('☀️ Radiación ',estado_lux,maximo_lux,minimo_lux,valor_actual_lux)
        res += dameCadenaPropiedad('🌡 Temperatura ',estado_temperatura,maximo_temperatura,minimo_temperatura,valor_actual_temperatura)
        
        return res
        
    except Exception as err:
        print(f"Unexpected {err=}, {type(err)=}")
        
def lambda_handler(event, context):


    try:
        request_body = json.loads(event['body']) # EXtract the Body from the call
    except KeyError:
        request_body = ""
    
    try:
        request_msg = json.dumps(request_body['message'])#['chat']['id'] # Extract the message object which contrains chat id and text
    except KeyError:
        request_msg = ""
            
    try:
        chat_id = json.dumps(request_body['message']['chat']['id']) # Extract the chat id from message
    except KeyError :
        chat_id = ""
    
    try :
        command = json.dumps(request_body['message']['text']).strip('"') # Extract the text from the message
    except KeyError:
        command = ""

    telegram_msg = ""
    
    if command == "/saludo":
        telegram_msg = saludo()
    elif command == "resumen":
        telegram_msg = dameDatosEstados()
    else:
        telegram_msg = "🤷️"
    
    print(telegram_msg)
    
    chat_id = os.environ['CHATID']
    telegram_token = os.environ['TOKEN']

    api_url = f"https://api.telegram.org/bot{telegram_token}/"

    params = {'chat_id': chat_id, 'text': telegram_msg}
    res = requests.post(f"{api_url}sendMessage", data=params).json()

    return {
        'statusCode': 200,
        'msg': json.dumps('respuesta enviada!'),
        'body': json.dumps('vamooos')
    }
